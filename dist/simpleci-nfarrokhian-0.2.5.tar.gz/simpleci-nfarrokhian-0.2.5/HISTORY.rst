=======
History
=======

0.1.0 (2021-07-04)
------------------

* First release on PyPI.
