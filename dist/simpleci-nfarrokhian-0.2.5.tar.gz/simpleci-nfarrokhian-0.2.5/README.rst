========
simpleci
========


.. image:: https://img.shields.io/pypi/v/simpleci.svg
        :target: https://pypi.python.org/pypi/simpleci

.. image:: https://img.shields.io/travis/nfarrokhian/simpleci.svg
        :target: https://travis-ci.com/nfarrokhian/simpleci

.. image:: https://readthedocs.org/projects/simpleci/badge/?version=latest
        :target: https://simpleci.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




concentration curve generator and concentration index calculator


* Free software: MIT license
* Documentation: https://simpleci.readthedocs.io.


Features
--------

* generates concentration curves from ordered data sets
* caluculates concentration indices (ACI and RCI)

Credits
-------

This package was created with Cookiecutter_ and `audreyr/cookiecutter-pypackage`_.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
