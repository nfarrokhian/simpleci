=====
Usage
=====

To use simpleci in a project::

    import simpleci
