"""Unit test package for simpleci."""
