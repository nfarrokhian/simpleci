"""Top-level package for simpleci."""

__author__ = """Nathan Farrokhian"""
__email__ = 'n.farrokhian@gmail.com'
__version__ = '0.1.0'
